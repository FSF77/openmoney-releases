# OpenMoney

<p align="center">
  <strong>Aplicativo financeiro moderno, nativo e open source para Apple macOS e iOS/iPadOS, inspirado no clássico Microsoft Money 99.</strong>
</p>

<p align="center">
  <img src="Sources/OpenMoney/Resources/icon-1024.png" alt="OpenMoney Icon" width="128" height="128" />
</p>

---

## 🌟 Visão Geral

O **OpenMoney** combina o poder de controle financeiro e o rigor contábil do clássico Microsoft Money 99 com as tecnologias mais modernas do ecossistema Apple (SwiftUI nativo). Seus dados pertencem exclusivamente a você: a base de dados é armazenada em um arquivo `openmoney.json` limpo e legível, sem dependência de servidores proprietários, cadastros externos ou telemetria.

### ✨ Principais Características

- **💎 Design System Liquid Glass**: Interface moderna com efeito de vidro fosco translúcido (*glassmorphism* nativo com `.ultraThinMaterial`), iluminação ambiente, gradientes especulares nas bordas e cartões flutuantes para saldos e métricas.
- **⚡ 100% Nativo & Ultrarrápido**: Desenvolvido em Swift + SwiftUI puro. O aplicativo compilado para macOS consome apenas ~2 MB em disco e inicia instantaneamente com mínimo uso de memória.
- **📱 Multiplataforma (macOS, iOS e iPadOS)**: Código compartilhado e interfaces adaptadas com ergonomia para Desktop e Mobile.
- **☁️ Sincronização Livre via Nuvem**: Escolha armazenar sua base no **iCloud Drive**, **Dropbox**, **Google Drive**, **OneDrive** ou localmente no Mac/iPhone.
- **📊 Controle Financeiro Rigoroso**: Saldo Real vs. Previsto, conciliação de lançamentos, gestão de faturas de cartão de crédito com pagamento parcial/adiantamento, lançamentos recorrentes, parcelamentos inteligentes, orçamentos e relatórios analíticos detalhados.

---

## 📐 Regras de Negócio e Governança Financeira

Esta seção consolida as regras fundamentais que regem o cálculo, a integridade e a operação do OpenMoney:

### 1. Contas e Integridade Histórica
- **Impossibilidade de Exclusão de Contas com Lançamentos**: Para proteger a rastreabilidade patrimonial e os relatórios fiscais/contábeis, o OpenMoney **não permite a exclusão física** de contas que possuam lançamentos vinculados. Caso o usuário tente excluir uma conta com movimentações, o sistema bloqueia a operação, informa o total de lançamentos e sugere a desativação da conta com 1 clique.
- **Desativação (Arquivamento) de Contas**: Contas inativas mantêm todo o seu histórico intacto em relatórios, fluxos de caixa e evolução patrimonial, mas deixam de aceitar novos lançamentos ou transferências. Podem ser reativadas a qualquer momento.
- **Exclusão de Contas Sem Uso**: Somente contas com **0 lançamentos** podem ser excluídas definitivamente, mediante confirmação expressa do usuário.

### 2. Cartão de Crédito e Faturas
- **Ciclo de Fechamento e Vencimento**: Cada cartão de crédito possui configuração do dia de fechamento (`closeDay`), dia de vencimento (`dueDay`) e conta de débito padrão (`pay`).
- **Alocação Padrão por Data**: Despesas lançadas até o dia de fechamento integram a fatura do mês corrente (vencendo no mês seguinte). Despesas posteriores à data de fechamento entram na fatura seguinte.
- **Seleção Manual de Fatura (Override)**: Embora o sistema calcule a fatura padrão com base na data de fechamento, o usuário pode **escolher manualmente outra fatura** para qualquer lançamento (ex.: postergar ou antecipar uma compra de fechamento tardio). Essa opção está disponível tanto no macOS quanto no iOS/iPadOS, na barra de inserção e na edição do lançamento.
- **Pagamento Parcial e Adiantamento de Fatura**:
  - O usuário pode registrar pagamentos totais ou parciais em qualquer data antes ou depois do vencimento (ex.: fatura de R$ 1.000 em Outubro com vencimento em 05/11; pagamento de R$ 500 no dia 15/10).
  - **Abatimento Automático no Vencimento**: A rotina automática de conciliação de faturas (`syncCards`) monitora todos os pagamentos parciais e despesas vinculadas à chave da fatura (`ik`). No vencimento, o sistema gera o agendamento de cobrança cobrando **apenas o saldo remanescente**.
  - **Fatura Liquidada**: Se os pagamentos cobrirem 100% da fatura (saldo restante $\le 0$), a cobrança automática no vencimento é cancelada e a fatura recebe o status **LIQUIDADA**.

### 3. Edição e Migração de Lançamentos entre Contas
- **Mover Lançamento de Conta**: Na tela de edição de lançamentos (`TransactionEditSheet`), é possível alterar a conta do lançamento (`selectedAccId`).
- **Adequação Automática de Cartão de Crédito**:
  - Ao mover uma compra para um cartão de crédito, o sistema calcula e associa a chave da fatura correspondente (`ik`), permitindo ajuste manual.
  - Ao mover de um cartão para uma conta corrente ou dinheiro, a associação de fatura é removida (`ik = nil`).
- **Séries Recorrentes e Parceladas**: Caso o lançamento faça parte de um parcelamento ou recorrência e a edição seja aplicada para lançamentos futuros (`scope == .forward`), todas as parcelas futuras não conciliadas são transferidas para a nova conta de destino.
- **Transferências**: Ao mover uma perna de uma transferência para outra conta, a contraparte par da transferência tem sua referência (`peer`) e sua descrição atualizadas de forma atômica e consistente.

### 4. Confirmações de Exclusão (Prevenção de Perda Acidental)
- **Lançamentos Avulsos**: Ao clicar na lixeira (macOS) ou deslizar para excluir (iOS), o sistema exige confirmação com os dados do lançamento (beneficiário, valor e data).
- **Lançamentos em Série (Parcelados / Recorrentes)**: Abre o diálogo de escopo para escolha entre excluir apenas o lançamento selecionado ou todos os futuros da série (lançamentos já conciliados nunca são excluídos).
- **Exclusão de Lançamentos em Lote (Por Período e/ou Conta)**:
  - Rotina acessível diretamente na barra de menus do macOS em **Lançamentos › Excluir Lançamentos em Lote...** e **Arquivo › Excluir Lançamentos por Período / Conta...** (e na aba Base no iOS).
  - **Escopo Flexível de Contas**: Permite executar a limpeza em uma conta individual ou em todas as contas da base de dados simultaneamente.
  - **Escopo Flexível de Período**: Suporta remoção de "Todo o Histórico" ou de um "Período Específico" delimitado por Data Inicial e Data Final (com botões de atalho: Ano Atual, Ano Anterior, Mês Atual, Últimos 12M e Até Hoje).
  - **Preservação Estrita de Contas e Categorias**: Contas cadastradas, seus tipos, saldos iniciais de abertura (`opening`), categorias, subcategorias, regras de recorrência e orçamentos planejados são **100% preservados**. Apenas as movimentações de lançamentos selecionadas são excluídas.
  - **Tratamento de Transferências Vinculadas**: Opção configurável para excluir automaticamente a contrapartida de transferências em outras contas (evitando lançamentos órfãos) ou desvincular a contrapartida mantendo-a avulsa.
  - **Aviso Obrigatório de Risco e Confirmação**: Apresenta painel visual de alerta de ação definitiva, com resumo estatístico ao vivo (*live preview* de quantidade de lançamentos, receitas, despesas, saldo líquido e contas impactadas). Exige confirmação explícita via checkbox antes de liberar o botão de exclusão.
  - **Geração Compulsória de Arquivo de Backup**: Antes de efetivar qualquer remoção, o sistema obriga a exportação de uma cópia de segurança completa em JSON através do `NSSavePanel` (e cópia de contingência automática no disco). Caso o usuário cancele o diálogo de backup, **a exclusão é abortada imediatamente**.
  - **Recálculo Atômico dos Módulos**: Após a exclusão, as faturas de cartão de crédito (`syncCards`), índices em memória ($O(1)$) e relatórios são recalculados instantaneamente.
- **Categorias Sem Uso**: Categorias sem lançamentos vinculados exigem confirmação explícita antes de serem removidas.
- **Categorias Em Uso**: Categorias que possuam lançamentos vinculados não podem ser excluídas diretamente; o sistema exige a indicação de uma categoria de substituição para reclassificar os registros.

### 5. Hierarquia de Planejamento e Responsividade
- **Ordem Unificada do Módulo Planejamento**: Em ambas as plataformas (macOS e iOS), a ordem oficial é:
  1. **Fluxo de Caixa**
  2. **Relatórios**
  3. **Orçamento**
  4. **Categorias**
- **Menu da Barra Superior (macOS)**: O módulo Planejamento conta com menu dedicado na barra de menus do macOS (`CommandMenu("Planejamento")`), com atalhos diretos (`Cmd + Option + 1` para Fluxo de Caixa, `Cmd + Option + 2` para Relatórios, `Cmd + Option + 3` para Orçamento, `Cmd + Option + 4` para Categorias e `Cmd + Shift + F` para Pesquisar em Toda a Base).
- **Escala Visual Responsiva**: Telas com grandes matrizes de dados (como Fluxo de Caixa e Orçamento Anual) são calibradas para exibição nítida a 100% em resoluções Full HD (1920x1080) e, em telas ou janelas menores, adaptam sua escala visual proporcionalmente (escala adaptativa até 60%) para exibir todos os 12 meses simultaneamente sem cortes horizontais.

### 6. Relatórios vs. Fluxo de Caixa (Tratamento de Transferências e Categorias)
- **Filtro Estrito nos Relatórios Mensais de Receitas/Despesas**:
  - Transferências entre contas (`xfer != nil` ou `peer != nil`) e lançamentos de categorias com a opção "Considerar nos Relatórios" desmarcada (incluindo categorias padrão de transferência como `"Transferencias (C)"` e `"Transferencias (D)"`) **não aparecem nem são somados** nos totais de receitas e despesas da tela de Relatórios (`ReportsView` no macOS e `iOSReportsTab` no iOS).
  - Cada categoria possui no seu cadastro/edição a opção configurável **"Considerar nos relatórios"** (`includeInReports`). Categorias fora dos relatórios recebem o badge visual `"Fora dos Relatórios"`.
- **Preservação Integral do Fluxo de Caixa**:
  - Essa exclusão de relatórios **NÃO se aplica ao Fluxo de Caixa**. O motor do Fluxo de Caixa (`CashFlowEngine`) processa rigorosamente todas as contas, transferências e categorias para assegurar a exatidão matemática do saldo anterior, do resultado financeiro e do saldo final em caixa/bancos.

### 7. Performance com Grandes Volumes de Dados
- **Indexação em Memória $O(1)$**: Caches estruturados por conta e por mês (`cachedTxsByAccount`, `cachedMonthData`).
- **Gravação Assíncrona Não-Bloqueante**: O salvamento da base JSON é executado em thread secundária com *debounce*, garantindo resposta instantânea mesmo em bases com mais de 30.000 lançamentos e arquivos de 5 MB+.

### 8. Importação Segura: Pré-Verificação e Criação Automática de Contas
- **Verificação Prévia de Contas (Prevenção de Importação Incorreta)**: Antes de processar e inserir qualquer transação na base a partir de arquivos CSV ou QIF, a rotina de importação escaneia e valida previamente todas as contas mencionadas no arquivo.
- **Resolução Automática da Coluna "Conta" no CSV**:
  - Na Central de Importação CSV, ao selecionar *"Automático (usar coluna 'Conta' do CSV)"*, o sistema analisa a coluna correspondente de cada linha e vincula o lançamento diretamente à respectiva conta (ex: *Nubank*, *Banco Inter*, *Itaú*).
  - **Filtro Estrito contra Cabeçalhos**: O sistema ignora automaticamente textos que correspondam ao cabeçalho da coluna (como `"Conta"`, `"Account"`, `"Nome da Conta"`, etc.), garantindo que o nome da coluna do arquivo nunca seja criado ou associado como uma conta real.
  - **Registro Efetivo no Banco de Dados**: Novas contas encontradas no CSV são adicionadas formalmente à base de dados (`db.accounts`), aparecendo de imediato na barra lateral e eliminando contas órfãs.
- **Criação Antecipada de Contas Inexistentes**: Caso uma ou mais contas citadas no arquivo não estejam previamente cadastradas no banco de dados, o sistema cria automaticamente as contas antes de vincular os lançamentos, evitando categoricamente que transações sejam alocadas na conta errada ou fiquem órfãs com identificadores inválidos.
- **Inferência Inteligente do Tipo de Conta**: O tipo da nova conta criada é inferido dinamicamente pelo nome contido no arquivo:
  - Nomes contendo termos como *"Cartão"*, *"Card"* ou *"Crédito"* recebem o tipo `Cartão de crédito`.
  - Termos como *"Poupança"* ou *"Savings"* recebem o tipo `Poupança`.
  - Termos como *"Investimento"* ou *"Invest"* recebem o tipo `Investimento`.
  - Termos como *"Dinheiro"* ou *"Cash"* recebem o tipo `Dinheiro`.
  - Demais contas recebem o tipo padrão `Corrente`.
- **Garantia de Integridade em Bases Limpas**: Ao importar um arquivo sem coluna de contas em uma base de dados que ainda não possua nenhuma conta cadastrada, o sistema cria antecipadamente uma conta padrão (*"Conta Corrente"*), garantindo que todos os lançamentos tenham uma conta válida associada.
- **Vínculo Correto de Transferências no QIF**: Em arquivos QIF com marcação de transferência entre contas (`[NomeDaConta]`), o sistema pré-cadastra a conta de contraparte se ela ainda não existir, preservando o relacionamento bidirecional da transferência em vez de convertê-la incorretamente em categoria avulsa.

### 9. Ajuste Automático de Previsões Orçamentárias Temporárias
- **Conceito de Previsão Temporária**: Lançamentos iniciados com o prefixo `Previsão` (ex.: *Previsão Posto*, *Previsão Mercado*, *Previsão Farmácia*) funcionam como reservas prévias de teto de gastos no mês.
- **Abrangência Global Multiconta**: Ao acionar o botão **"Ajustar Previsões"**, o sistema avalia as previsões do mês selecionado em todas as contas cadastradas.
- **Apuração por Categoria em Todas as Contas**: Para cada categoria com previsão, o sistema consolida todos os gastos já realizados no mês em **todas as contas** ativas (excluindo outras previsões e transferências).
- **Abatimento Determinístico sem Dedução Duplicada**: O valor gasto é subtraído do teto da previsão. A base original é memorizada de forma transparente na nota (`[Previsão base: R$ X,XX]`), permitindo acionar o botão quantas vezes for necessário ao longo do mês à medida que novas compras entrarem, recalculando sempre a partir do teto inicial sem duplicar reduções.
- **Exclusão Automática de Previsão Esgotada**: Se as despesas da categoria atingirem ou superarem o teto previsto (saldo remanescente $\le 0$), a previsão temporária é excluída automaticamente e um aviso destacado alerta que o saldo daquela previsão foi integralmente consumido.

---

## 🚀 Como Rodar e Compilar

### 1. Compilação Nativa macOS (Script Automático)

Para compilar o aplicativo diretamente do terminal sem necessidade de abrir o Xcode:

```bash
# 1. Torne o script executável (caso necessário)
chmod +x ./build-app.sh

# 2. Compile e gere o bundle nativo OpenMoney.app
./build-app.sh

# 3. Abra o aplicativo gerado
open OpenMoney.app
```

O script `./build-app.sh`:
- Gera automaticamente os ícones de alta resolução em formatos `.icns` e `.png` (1024x1024).
- Compila de forma otimizada (`-O`) visando arquitetura Apple Silicon (`arm64`) nativa.
- Gera o bundle `OpenMoney.app` assinado *ad-hoc* pronto para execução (compilação e assinatura são feitas em `/tmp` para evitar atributos do Finder/iCloud que invalidam a assinatura).
- Gera o pacote de distribuição `dist/OpenMoney-<versão>.zip` e o feed `dist/version.json`.
- Aceita parâmetros: `./build-app.sh [VERSÃO] ["Notas"] [--publish]`. Com `--publish`, envia a nova versão ao repositório público de releases (veja a seção *Atualização Automática pela Internet*).

### 2. Compilação para iOS / iPadOS (Script Automático)

Para gerar os pacotes do app para iOS (Simulador ou Dispositivo / `.ipa`):

```bash
./build-ios.sh
```

O script oferece 3 opções:
1. **Simulador iOS**: Gera `build/ios/OpenMoney-Simulator.app` (basta arrastar para a janela do simulador para instalar).
2. **Dispositivo iOS (.ipa)**: Compila o binário `arm64` nativo e empacota em `build/ios/OpenMoney.ipa` e `OpenMoney-Device.app`.
3. **Instalação Direta**: Compila e instala diretamente no simulador que estiver aberto no momento.

### 3. Abrir e Rodar no iPhone Físico via Xcode (macOS / iOS / iPadOS)

Para instalar diretamente no seu iPhone conectado ao Mac:

```bash
open OpenMoney.xcodeproj
```

1. No topo do Xcode, escolha o target **OpenMoney** e selecione o seu **iPhone** (ou um Simulador).
2. Na aba **Signing & Capabilities**, selecione a sua conta Apple (*Team*).
3. Pressione **Cmd + R** (ou o botão Play ▶) para compilar e instalar no iPhone.

---

## 📋 Funcionalidades Implementadas

### 1. Gestão Completa de Contas e Patrimônio Global
- **Múltiplos Tipos de Conta Suportados**:
  - **Corrente**: Movimentação bancária diária, transferências e pagamentos.
  - **Poupança**: Contas de reserva e rendimento básico.
  - **Investimento**: Aplicações de renda fixa/variável e patrimônio investido.
  - **Dinheiro**: Controle de carteira, pequenos gastos em espécie e caixinha.
  - **Cartão de Crédito**: Gestão de limite, fechamento, vencimento e faturas.
- **Saldos em Tempo Real (Real vs. Previsto)**:
  - **Saldo Real**: Apuração estrita das transações já conciliadas no extrato.
  - **Saldo Previsto**: Projeção com lançamentos pendentes e parcelas futuras do mês selecionado.
  - **Patrimônio Consolidado no Rodapé**: Indicador permanente na barra lateral do patrimônio real e projetado de todas as contas ativas.
- **Arquivamento e Desativação Segura de Contas**:
  - Desativação de contas inativas com 1 clique (mantendo o histórico completo em relatórios e auditorias).
  - Bloqueio rígido de novos lançamentos em contas inativas, com banner informativo e botão de reativação imediata.
  - Separação visual com seções dedicadas: **Contas Ativas** e **Contas Inativas** (com contadores e badge `INATIVA`).
  - **Contas Favoritas**: toggle "Favoritar conta" no cadastro; as favoritas aparecem em um grupo próprio **Favoritas** no topo da barra lateral, seguido de **Contas Ativas** e **Contas Inativas**.
  - **Grupos recolhíveis**: clique no título de cada grupo para recolher/expandir (útil com muitas contas inativas). O estado é gravado e restaurado ao reabrir o app.
  - O botão **+ Nova conta** fica no final da lista, abaixo das contas inativas.
- **Proteção Contra Exclusão Acidental**:
  - Bloqueio total de exclusão para contas que contenham lançamentos, sugerindo a desativação da conta.
  - Exclusão permitida apenas para contas sem lançamentos (0 registros), com alerta de confirmação definitiva.
- **Reordenação Personalizada**:
  - **macOS**: Arraste e solte (*drag & drop*) ou menu de contexto com atalhos "Mover para cima" / "Mover para baixo".
  - **iOS**: Ações contextuais táteis de reordenação. A sequência é salva de forma persistente no arquivo JSON.

### 2. Gestão Avançada de Cartões de Crédito e Faturas
- **Ciclo Completo de Fechamento e Vencimento**: Configuração individual de dia de fechamento (`closeDay`), dia de vencimento (`dueDay`) e conta para débito automático (`pay`).
- **Painel de Status da Fatura do Mês**:
  - Exibição destacada em Liquid Glass no cabeçalho da conta com:
    - **Total da Fatura** (soma de despesas alocadas).
    - **Já Pago** (adiantamentos e pagamentos parciais realizados).
    - **Saldo a Pagar** / Status **LIQUIDADA** (verde esmeralda).
    - Datas exatas de fechamento, vencimento e conta de débito vinculada.
- **Botão "Pagar / Adiantar..." (`InvoicePaymentSheet`)**:
  - Interface dedicada no macOS e iOS para efetuar pagamentos integrais ou adiantamentos parciais em qualquer data.
  - Atalho instantâneo **"Preencher Saldo Restante"**.
  - Seleção da conta de débito e data do pagamento.
- **Abatimento Automático no Vencimento**:
  - Caso o usuário efetue um pagamento parcial antecipado, a transação automática gerada no vencimento cobra **estritamente o saldo remanescente**.
  - Caso a fatura seja quitada integralmente com antecedência, o lançamento automático no vencimento é cancelado e removido.
- **Seleção Manual de Fatura (Override)**:
  - Seletor de fatura presente tanto na barra rápida de inserção quanto na edição do lançamento.
  - Permite alocar compras para faturas anteriores ou futuras (com indicação da fatura padrão calculada pelo fechamento).
- **Identificação Visual**: Tag roxa com o mês da fatura (`Fatura Mês/Ano`) em cada linha de lançamento de cartão no macOS e iOS.

### 3. Livro-Caixa e Tabela de Lançamentos Inteligente
- **Autocompletar Preditivo de Beneficiário com Classificação Automática**:
  - Ao digitar os primeiros caracteres do beneficiário, o OpenMoney busca no histórico e exibe sugestões contextuais.
  - **Classificação Imediata**: Ao selecionar a sugestão (via clique, toque ou tecla `Enter`), o sistema preenche automaticamente a **última categoria** e o **tipo** (Despesa/Receita) utilizados para aquele beneficiário.
  - **macOS**: Sugestões flutuantes integradas à barra de inserção com navegação por teclado.
  - **iOS**: Carrossel horizontal de chips de sugestão tátil logo abaixo do campo.
- **Mover Lançamento de Conta**:
  - Na tela de edição de lançamentos (`TransactionEditSheet`), é possível selecionar uma nova conta de destino.
  - Conversão inteligente de faturas de cartão e propagação atômica para séries recorrentes, parcelamentos futuros e transferências.
- **Agrupamento Cronológico Dia a Dia**:
  - Extrato agrupado por data com indicação do dia da semana (ex: `15/10/2026 · Qui`).
  - Fechamento diário com indicação do saldo real e previsto acumulado ao final de cada dia.
- **Colunas Redimensionáveis no macOS**: Divisores arrastáveis entre as colunas (**Data**, **Descrição/Beneficiário**, **Categoria**, **Nota** e **Valor**) com salvamento do layout.
- **Conciliação Bancária Interativa**: Botão circular de conciliação com estilo Liquid Glass para alternar entre pendente e conciliado com 1 clique/toque.
- **Confirmação Nativa de Exclusão**: Diálogo de segurança exibindo descrição, valor e data antes de excluir lançamentos avulsos.
- **Busca e Filtro em Tempo Real**: Barra de busca instantânea filtrando por beneficiário, categoria ou anotações na velocidade da digitação no mês corrente.
- **Navegação Rápida entre Meses e Seletor Direto de Ano/Mês (`MonthYearQuickPicker`)**:
  - Além da navegação sequencial com setas (`‹` e `›`), o cabeçalho do mês é interativo (`calendar` + `chevron.down`).
  - Permite abrir popover com controle de anos (stepper `‹ Ano ›`, menu com anos existentes na base de dados) e grade com os 12 meses (Jan a Dez).
  - Salto imediato de múltiplos anos ou meses com 1 clique (ex: voltar de 2026 para 2020), além de botão de retorno rápido para o mês atual (*Hoje*).
- **Rodapé Mensal Flutuante**: Indicadores de total de receitas, despesas e saldo líquido do mês selecionado.
- **Rotina de Exclusão de Lançamentos em Lote (Barra de Menus macOS e Base iOS)**:
  - Menu **Lançamentos › Excluir Lançamentos em Lote...** e Menu **Arquivo › Excluir Lançamentos por Período / Conta...**.
  - Permite expurgar movimentações de uma conta específica ou de todas as contas simultaneamente.
  - Suporta seleção entre "Todo o Histórico" ou intervalo personalizado com data inicial e final (com atalhos: Ano Atual, Ano Anterior, Mês Atual, Últimos 12M e Até Hoje).
  - Preserva estritamente as contas, seus saldos de abertura e todas as categorias e subcategorias cadastradas.
  - Alerta de risco em tempo real com estatísticas de impacto financeiro (*live preview*) e confirmação obrigatória.
  - **Backup Prévio Obrigatório**: Exportação compulsória de arquivo JSON da base completa via `NSSavePanel` antes de efetuar a exclusão (se cancelado o backup, a exclusão é abortada).
  - Recálculo dinâmico automático de conciliações e faturas de cartão de crédito (`syncCards`).
- **Ajuste Inteligente de Previsões Orçamentárias ("Ajustar Previsões")**:
  - **Botão na Barra do Mês (macOS e iOS)**: Localizado estrategicamente ao lado do filtro e da busca rápida no cabeçalho do mês.
  - **Identificação Automática**: Localiza instantaneamente todos os lançamentos do mês cuja descrição comece com `Previsão` (ex: `Previsão Posto`, `Previsão Mercado`), sem distinção de maiúsculas/minúsculas e acentos.
  - **Apuração Global de Gastos da Categoria**: Varre todas as contas ativas no mês e calcula o total dos gastos efetivamente realizados na mesma categoria (desconsiderando transferências e outras previsões).
  - **Abatimento Proporcional Inteligente**: Reduz o valor da previsão com base nos gastos reais da categoria. A base original é gravada de forma transparente na nota (`[Previsão base: R$ X,XX]`), garantindo que execuções sucessivas não causem deduções repetidas.
  - **Exclusão de Previsão Esgotada**: Caso as despesas da categoria alcancem ou superem o valor previsto (saldo restante $\le 0$), o lançamento temporário de previsão é **excluído automaticamente**, emitindo aviso em destaque: *"Não há mais previsão disponível"*.
  - **Relatório de Ajuste Instantâneo**: Exibe modal/alerta com o resumo categorizado das previsões ajustadas, previsões esgotadas/excluídas e previsões que permaneceram em dia.

### 4. Pesquisa em Toda a Base de Dados (Busca Global)
- **Consulta Global Unificada em Todas as Contas e Períodos**:
  - Acessível pela barra lateral (*Pesquisa Global*), pelo atalho de teclado `Cmd + Shift + F`, pelo menu *Lançamentos*, pelo botão na barra de navegação de lançamentos no macOS ou pela aba dedicada **Buscar** no iOS.
  - **Busca Multicritério com Suporte a 4 Campos Principais**:
    - **Descrição / Favorecido**: Busca flexível por nome ou partes do beneficiário.
    - **Categoria**: Busca por termos da categoria principal ou subcategoria hierárquica.
    - **Nota / Observação**: Busca por anotações e memorandos (ex.: `IPVA 2024`, `Reembolso`, `Nota Fiscal`).
    - **Valor**: Reconhecimento inteligente de valores com ou sem centavos, decimais com vírgula ou ponto (ex.: `150`, `150,00`, `150.00`, `1.500,00`, `R$ 89,90`).
  - **Exibição Estruturada em Linhas**: Tabela completa exibindo **Data**, **Conta**, **Descrição / Favorecido** (com badges de recorrência `⟳` e parcelamento `x/y`), **Categoria**, **Nota / Observação** e **Valor** formatado com cor correspondente.
  - **Filtros Rápidos Complementares**: Filtro por conta (Todas ou conta específica) e por tipo de lançamento (Todos, Receitas `+`, Despesas `−`).
  - **Navegação Direta ao Registro com Destaque Visual**:
    - Ao clicar em qualquer linha da busca, o sistema abre a conta de destino, define o mês correspondente da data do lançamento, rola a tela até a posição exata da movimentação e a destaca com iluminação e borda de ênfase visual.

### 5. Lançamentos Recorrentes e Parcelados Inteligentes
- **Recorrência Contínua**: Frequências **Diária**, **Semanal**, **Mensal** e **Anual** com projeção contínua nos meses seguintes.
- **Parcelamento Inteligente**:
  - Divisão automática em até **120 parcelas** com cálculo exato de centavos (`splitAmt`).
  - Sufixo automático com numeração da parcela no beneficiário (ex.: `Notebook (1/10)`).
  - Ajuste de dias para meses com 28, 30 e 31 dias mantendo a consistência do vencimento.
- **Diálogo de Escopo de Alteração e Exclusão (`ScopeChoice`)**:
  - *Apenas este lançamento*.
  - *O selecionado e todos os futuros não conciliados*.
  - *Todos os lançamentos da série*.
  - **Proteção Absoluta**: Lançamentos que já foram conciliados no banco nunca são alterados ou excluídos em edições de série.

### 6. Transferências Entre Contas
- **Lançamento Duplo Espelhado Atômico**: Geração simultânea do débito na conta de origem e do crédito na conta de destino vinculados por UID compartilhado (`xfer`).
- **Atualização Sincronizada**: Alterar data, valor ou descrição em uma das pontas sincroniza a contraparte automaticamente. Excluir uma ponta remove o espelho correspondente.
- **Neutralidade Patrimonial**: No Fluxo de Caixa Global, transferências internas não distorcem as receitas ou despesas globais. Na visualização de conta individual, a transferência é computada com o detalhamento da conta de contrapartida.

### 7. Categorias e Subcategorias com Proteção de Dados
- **Hierarquia Estruturada em Dois Níveis**: Categorias Principais e Subcategorias organizadas rigorosamente em **Despesas** e **Receitas**.
- **Controle de Inclusão em Relatórios (`includeInReports`)**:
  - Opção no cadastro e edição para habilitar/desabilitar se a categoria é computada nos relatórios mensais de receitas e despesas.
  - Indicador visual com badge `"Fora dos Relatórios"` para categorias configuradas para não pontuar nos relatórios analíticos.
- **Prevenção de Lançamentos Órfãos**:
  - Categorias sem lançamentos exigem confirmação explícita antes de serem excluídas.
  - Categorias em uso não podem ser excluídas diretamente; o sistema abre a modal de substituição (`CategoryDeleteSheet`) para reclassificar todos os lançamentos para outra categoria.
- **Importação e Exportação Estruturada em CSV**:
  - **Exportação com Padrão Hierárquico**: Gera arquivo CSV contendo `"Tipo"`, `"Categoria Principal"`, `"Subcategoria"` e a coluna combinada `"Categoria Completa"` formatada com o símbolo `"›"` (ex.: `"Alimentação › Bares e Restaurantes"`, `"Transportes › Combustível"`).
  - **Importação Resiliente**: Detecção automática de delimitadores (`;`, `,`, tab), suporte a formatos combinados com separadores (`›`, `>`, `/`), criação automática da categoria-pai e prevenção contra duplicatas.
  - Acesso direto por botões dedicados no cabeçalho da tela no macOS e no menu de ações no iOS.

### 8. Planejamento Financeiro: Orçamento Mensal (Budget)
- **Metas e Tetos de Gastos por Categoria**: Definição de limites mensais por categoria de despesa.
- **Soma Acumulada de Subcategorias**: Categorias principais que possuem subcategorias calculam e exibem automaticamente a soma acumulada das metas e dos gastos realizados.
- **Barras de Progresso Liquid Glass**: Gradientes luminosos indicando o percentual consumido, alertas visuais para limites estourados (vermelho) e indicação do saldo disponível restante.
- **Totalizador Geral**: Resumo no rodapé com o total planejado vs. total realizado no mês.

### 9. Relatório Analítico de Fluxo de Caixa (Mensal, Trimestral, Semestral e Anual)
- **Matriz Financeira Multidimensional Completa**:
  - Visão analítica matricial consolidada de todas as receitas e despesas organizadas por categoria e subcategoria.
- **Períodos Flexíveis de Análise**:
  - **Mensal**: 12 meses do ano (`01/AAAA` a `12/AAAA`) + Total acumulado do ano.
  - **Trimestral**: 4 trimestres consolidados + Total.
  - **Semestral**: 2 semestres consolidados + Total.
  - **Anual**: Comparativo plurianual de todos os anos da base + Total histórico.
- **Linhas Analíticas de Fechamento Contábil**:
  - Subtotais automáticos por categoria principal (`Total [Categoria]`) e lançamentos diretos sem subcategoria (`[Categoria] - Não-atribuído`).
  - Linhas destacadas de `Total Rendimento` e `Total Despesas`.
  - **Rendimento menos Despesas**: Resultado operacional líquido do período (superávit em verde, déficit em vermelho).
  - **Saldo Anterior Acumulado**: Apuração matemática exata do saldo real transitado de períodos anteriores (saldos iniciais + movimentações passadas).
  - **Saldo Final Acumulado**: Consolidação do saldo em caixa/bancos ao final de cada período (`Saldo Anterior + Rendimento - Despesas`).
- **Filtros e Controles Avançados**:
  - **Todas as Contas (Visão Consolidada)**: Sem transferências internas, refletindo a variação real do patrimônio global.
  - **Conta Específica**: Detalha movimentações individuais e computa transferências sob a categoria `Transferência`.
  - **Filtro de Status**: *Todos os Status*, *Apenas Conciliados* (auditoria fiscal/realizado) ou *Apenas Previstos/Futuros* (projeção orçamentária).
  - **Filtro de Regime de Data**: *Data do Lançamento* (regime de competência) vs. *Data de Pagamento da Fatura* (regime de caixa de cartões).
  - Navegador de anos (`‹ AAAA ›`), busca em tempo real e botões de **Recolher/Expandir Tudo**.
- **Layout Responsivo Calibrado**:
  - Exibição nítida a 100% nativo em resoluções Full HD (1920x1080).
  - Redimensionamento proporcional automático (escala adaptativa até 60%) em janelas ou monitores menores para manter todos os 12 meses visíveis sem cortes.
- **Exportação CSV Compatível com Excel e Planilhas**:
  - Delimitador `;`, decimais com vírgula BRL, metadados dos filtros ativos e codificação **UTF-8 com BOM** (abre perfeitamente no Excel, Numbers e Google Planilhas sem distorcer acentuação).

### 10. Relatórios e Análise Mensal
- **Exclusão de Transferências e Categorias Neutras**: Não exibe e não soma nos totais de receitas e despesas transferências entre contas e categorias marcadas como fora dos relatórios (ex.: "Transferencias (C)", "Transferencias (D)").
- **Navegação de Mês com Seletor Rápido (`MonthYearQuickPicker`)**:
  - Cabeçalho interativo com ícone de calendário e indicador de expansão (`calendar` e `chevron.down`) ao lado dos botões sequenciais de anterior (‹) e próximo (›), além do atalho "Hoje".
  - Popover de salto temporal em 2 cliques: seletor de anos (‹, ›, atalhos "Ano Anterior" / "Próximo" e menu suspenso com anos presentes no banco de dados), grade 4x3 dos 12 meses (com iluminação do mês selecionado e mês corrente) e botão "Mês Atual (Hoje)".
  - Disponível e sincronizado tanto no macOS (`ReportsView`) quanto no iOS (`iOSReportsTab`).
- **Cards de Métricas Liquid Glass**: Receitas, Despesas, Saldo Líquido do Mês e **Taxa de Poupança** (*Savings Rate* percentual).
- **Distribuição Gráfica por Categoria**: Gráfico de barras proporcional com ranking e percentual de participação de cada categoria e subcategoria no total do mês.
- **Impressão e Exportação em PDF Adaptada em 1 Página (`MonthlyReportPrintView` / `MonthlyReportPDFGenerator`)**:
  - **Menu e Atalhos de Impressão**: Menu "Imprimir / PDF" na barra superior do relatório no macOS com atalho global `Cmd + P`, item no menu Arquivo/Exportar, e botão na barra de navegação/rodapé no iOS.
  - **Impressão Nativa**: Diálogo padrão de impressão do macOS (`NSPrintOperation`) com suporte completo a impressoras físicas, AirPrint e "Salvar como PDF...", e `UIPrintInteractionController` no iOS.
  - **Exportação Direta em PDF**: Geração vetorial direta de arquivo `.pdf` via `NSSavePanel` no macOS e `ShareLink` (Salvar em Arquivos, AirDrop, etc.) no iOS.
  - **Design Calibrado para 1 Página A4**: Layout executivo profissional (595 x 842 pt) com cabeçalho oficial OpenMoney com data/hora de emissão, cards KPI de resumo financeiro, distribuição lado a lado em 2 colunas (Receitas à esquerda, Despesas à direita) com barras de participação percentual e condensação adaptativa de subcategorias e categorias excedentes, barra de saldo líquido final e rodapé de autenticação, garantindo adaptação perfeita em 1 página única.

### 11. Central de Importação e Exportação (CSV e QIF — Microsoft Money 99)
- **Central de Importação/Exportação CSV (`CSVImportExportSheet`)**:
  - Modal dedicada no macOS (`Cmd + Option + I`) e na aba Base de Dados no iOS.
  - Permite escolher a conta de destino (automática pela coluna do CSV ou conta fixa selecionada).
  - **Pré-Verificação e Auto-Criação de Contas**: Examina a coluna de contas antes de importar e cria automaticamente as contas ausentes no cadastro antes de associar os lançamentos, evitando que transações de contas distintas sejam misturadas na mesma conta.
  - **Flag de Controle de Duplicidade** (*Permitir importação de lançamentos duplicados*):
    - **Desativado (Padrão de Segurança)**: Verificação instantânea $O(1)$ por chave única (`conta|data|valor|favorecido`). Ignora transações idênticas já cadastradas e informa no resumo final a quantidade de lançamentos duplicados ignorados.
    - **Ativado**: Permite importar transações idênticas caso o usuário opte por carregar deliberadamente lançamentos com mesma conta, data, valor e favorecido.
  - Disponível também diretamente no seletor de arquivos do macOS (`NSOpenPanel`) através de checkbox integrada como *accessory view*.
- **Exportação CSV Universal**: Por conta individual ou de todas as contas consolidadas com cabeçalho padrão, valores BRL e UTF-8 com BOM (compatível com Excel, Numbers e Google Planilhas).
- **Importação QIF do Microsoft Money 99 e Quicken**:
  - Suporte completo ao formato `.qif` clássico.
  - Decodificação resiliente com fallback para **Windows CP1252 / Latin-1**, preservando acentos e caracteres especiais originais do Money 99.
  - Reconhecimento automático de contas bancárias, cartões de crédito, dinheiro e investimentos.
  - Identificação e pré-criação automática de contrapartes em transferências entre contas no padrão `[NomeDaConta]`.
  - Relatório pós-importação detalhado com total de transações importadas, duplicatas ignoradas, novas categorias cadastradas e novas contas criadas.

### 12. Gestão da Base de Dados na Barra de Menus (macOS) e Nuvem
- **Exibição do Nome da Base na Barra de Título e no Cabeçalho**:
  - A barra superior do aplicativo e a barra de título da janela do macOS exibem dinamicamente o nome do arquivo da base atualmente carregada (ex: `OpenMoney — openmoney.json`), assegurando total transparência sobre qual banco de dados está ativo em tempo real.
- **Criação de Nova Base de Dados**: Opção **Nova Base de Dados...** (`Cmd + N`) permitindo escolher nome de arquivo e pasta pelo `NSSavePanel` (iCloud, pasta de rede, etc.).
- **Acesso Completo via Menu Arquivo**:
  - *Nova Base de Dados...* (`Cmd + N`)
  - *Abrir Base de Dados...* (`Cmd + O`)
  - *Mover Base de Dados (Sincronizar)...* (`Cmd + Shift + M`)
  - *Central de Importação/Exportação CSV...* (`Cmd + Option + I`)
  - Menus suspensos unificados de *Exportar* e *Importar* (CSV, QIF, Backup JSON).
  - *Excluir Lançamentos por Período / Conta...* (limpeza em lote segura com backup prévio).
  - *Revelar Base no Finder*.
- **Menu Dedicado "Lançamentos" no macOS**:
  - *Excluir Lançamentos em Lote...* (com seletor de contas, datas, aviso de risco e backup obrigatório prévio).
- **Barra Lateral Limpa**: Os botões de gerenciamento de banco de dados foram transferidos para a barra de menus do sistema macOS, garantindo ergonomia e deixando os cartões de Patrimônio Líquido com total destaque visual.
- **Sincronização Livre na Nuvem**: Suporte nativo para armazenar a base `openmoney.json` no iCloud Drive, Dropbox, Google Drive, OneDrive ou localmente.
- **Gravação Atômica e Cópia de Segurança**: Toda escrita gera backup automático de segurança (`openmoney.json.bak`).
- **Arquitetura de Alta Performance ($O(1)$)**:
  - Cache estruturado em memória de lançamentos por conta e por mês.
  - Transição instantânea entre contas e meses, mesmo em bases com mais de **30.000 lançamentos** e arquivos JSON de mais de 5 MB.
  - Gravação assíncrona em thread secundária com *debounce*, eliminando qualquer travamento ou engasgo na interface do usuário.

### 13. Experiência Multiplataforma e Usabilidade
- **Menu Planejamento na Barra Superior do macOS**:
  - `Fluxo de Caixa` (`Cmd + Option + 1`)
  - `Relatórios` (`Cmd + Option + 2`)
  - `Orçamento` (`Cmd + Option + 3`)
  - `Categorias e Subcategorias` (`Cmd + Option + 4`)
- **Atalhos Globais no macOS**:
  - `Cmd + ?`: Abrir Ajuda e Manual do OpenMoney.
  - `Cmd + N`: Criar nova base de dados.
  - `Cmd + O`: Abrir base de dados existente.
  - `Cmd + Shift + M`: Mover/trocar localização da base.
  - `Cmd + Shift + F`: Pesquisa em toda a base de dados (Busca Global).
  - `Cmd + I`: Importar lançamentos CSV.
  - `Cmd + Option + I`: Central de importação/exportação CSV.
  - `Cmd + Shift + Q`: Importar arquivo QIF do Microsoft Money 99.
  - `Cmd + Shift + E`: Exportar backup completo JSON.
- **Navegação Nativa no iOS / iPadOS**: Abas dedicadas (**Contas**, **Buscar**, **Fluxo de Caixa**, **Relatórios**, **Orçamento**, **Categorias**, **Base**), suporte completo a gestos de deslizar (*swipe*), menus de contexto e integração com o seletor de arquivos nativo da Apple.

### 14. Sistema de Ajuda e Manual Integrado (Sincronizado Sempre com o README.md)
- **Menu "Ajuda" Nativo no macOS**:
  - Acesso direto pelo menu do sistema **Ajuda** ou pelo atalho `Cmd + ?` (`⌘?`).
  - Opções para abrir a janela de ajuda interativa, abrir o `README.md` no editor de texto externo e recarregar os dados do disco.
- **Sincronização Dinâmica em Tempo Real**:
  - O motor de ajuda (`HelpManager`) lê o arquivo `README.md` dinamicamente do disco em tempo de execução (checando diretório do projeto, recursos empacotados no bundle e fallback compilado `EMBEDDED_README`).
  - Qualquer alteração realizada no `README.md` reflete imediatamente na tela de ajuda através do botão "Recarregar", sem necessidade de reiniciar o aplicativo.
  - A rotina de compilação (`build-app.sh` e `build-ios.sh`) sincroniza automaticamente o `README.md` com o código-fonte (`HelpContent.swift`) e a pasta de recursos do aplicativo antes de cada build.
- **Visualizador Estruturado com Busca e Blocos Ricos**:
  - Navegação lateral por tópicos indexados (Visão Geral, Regras de Negócio, Funcionalidades, Como Compilar e Manual Completo).
  - Campo de busca instantânea filtrando tópicos e regras.
  - Renderização rica em Liquid Glass com suporte a cabeçalhos, marcadores, listas numeradas, citações e blocos de código com botão de cópia com 1 clique.
  - Acessível também pelo botão `?` no cabeçalho da barra lateral no macOS e pela aba **Base** no iOS/iPadOS.

### 15. Atualização Automática pela Internet (macOS)
- **Verificação ao Abrir e Sob Demanda**:
  - Ao iniciar, o app consulta silenciosamente se há uma versão mais nova; se não houver, nada é exibido.
  - Manualmente, use o menu **OpenMoney > Buscar Atualizações...** ou **Ajuda > Buscar Atualizações...**.
- **Janela de Atualização Disponível**:
  - Mostra versão atual, nova versão, data e as notas da versão, com os botões **Instalar e Reiniciar**, **Lembrar Mais Tarde** e **Ver no GitHub**.
  - O download exibe barra de progresso; ao concluir, o app descompacta o pacote, substitui o `OpenMoney.app`, fecha e reabre sozinho já atualizado.
- **Distribuição**:
  - O código-fonte fica no repositório privado; os pacotes ficam no repositório público [`FSF77/openmoney-releases`](https://github.com/FSF77/openmoney-releases), no formato `downloads/OpenMoney-<versão>.zip`, junto com o feed `version.json`.
  - A consulta ignora o cache do CDN do GitHub (usa o commit mais recente do repositório), detectando novas versões imediatamente após a publicação.
- **Instalação Inicial ou Manual**:
  - Instalação/atualização com um comando no Terminal:
    ```bash
    curl -fsSL https://raw.githubusercontent.com/FSF77/openmoney-releases/main/install.sh | bash
    ```
  - Se o macOS exibir *"OpenMoney está danificado e não pode ser aberto"* após baixar o `.zip` pelo navegador (o app não é notarizado pela Apple), execute uma única vez: `xattr -cr /Applications/OpenMoney.app`. As atualizações feitas pelo próprio app não exibem esse aviso.
- **Publicar uma Nova Versão (desenvolvedor)**:
  ```bash
  ./build-app.sh 1.0.15 "Notas da versão" --publish
  ```
  O script atualiza `VERSION` e `BUILD_NUMBER`, compila e assina o app, gera o `.zip` e o `version.json` e publica tudo no repositório de releases.

---

## 📁 Estrutura do Projeto

```text
ProjOpenMoney/
├── Package.swift                    # Configuração SPM (macOS 14+, iOS 17+)
├── build-app.sh                     # Script de compilação autônoma do OpenMoney.app (macOS)
├── build-ios.sh                     # Script de compilação do OpenMoney para iOS / iPadOS
├── README.md                        # Documentação completa e regras de negócio
├── VERSION / BUILD_NUMBER           # Versão e build atuais (atualizados pelo build-app.sh)
├── Sources/
│   └── OpenMoney/
│       ├── OpenMoneyApp.swift       # Entry point do app (@main), menu bar e ciclo de vida
│       ├── Models.swift             # Modelos de dados (Account, Transaction, Database) e helpers
│       ├── ImportersExporters.swift # Parsers de CSV e QIF (Money 99) e geradores de exportação
│       ├── Store.swift              # MoneyStore (gerenciamento de estado, I/O, regras de negócio)
│       ├── Views.swift              # Componentes de UI Desktop macOS e Design System Liquid Glass
│       ├── iOSViews.swift           # Componentes adaptados para iPhone e iPad
│       ├── UpdateManager.swift      # Atualização automática pela internet (feed, download, instalação)
│       ├── Resources/               # Ícones (.icns, .png)
│       └── Assets.xcassets/         # Asset Catalog com ícones para todas as resoluções
└── scripts/
    ├── generate-icon.swift          # Utilitário Swift para renderização procedural do ícone
    └── publish-release.sh           # Publica o .zip e o version.json no repositório de releases
```

---

## 🛠️ Tecnologias Utilizadas

- **Linguagem**: Swift 5.9+
- **Interface**: SwiftUI 5+ (materiais translúcidos nativos, escala responsiva, animações contínuas)
- **Frameworks Apple**: `SwiftUI`, `AppKit` (macOS), `UIKit` (iOS), `UniformTypeIdentifiers`
- **Armazenamento e Performance**: JSON Schema estruturado e atômico com indexação em memória $O(1)$, salvamento assíncrono em background (debounced, sem travamento de UI em bases com mais de 30.000 lançamentos) e importadores em lote otimizados via Sets hash.

---

## 📄 Licença

Distribuído sob a licença **MIT**. Consulte o arquivo `LICENSE` para mais detalhes.

*OpenMoney é um projeto independente de código aberto, concebido por entusiastas de finanças pessoais. Não possui afiliação, vínculo ou endosso da Microsoft Corporation.*
